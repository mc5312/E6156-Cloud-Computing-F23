import { Component } from '@angular/core';

@Component({
    selector: 'typography-cmp',
    templateUrl: 'typography.component.html'
})

export class TypographyComponent{}
