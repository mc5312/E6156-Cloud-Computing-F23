import { Component } from '@angular/core';

@Component({
    selector: 'regularforms-cmp',
    templateUrl: 'regularforms.component.html'
})

export class RegularFormsComponent{}
