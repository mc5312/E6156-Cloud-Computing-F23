import {Component, OnInit } from '@angular/core';

@Component({
    selector: 'fullscreen-map-cmp',
    templateUrl: 'fullscreenmap.component.html'
})

export class FullScreenMapsComponent implements OnInit{
    ngOnInit(){
	}
}
