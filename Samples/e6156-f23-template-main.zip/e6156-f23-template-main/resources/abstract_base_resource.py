#
# I sometimes have standard interfaces/base classes in my applications.
# We may get a chance to discuss in lectures but this is more SW style and
# not really cloud computing
#
from abc import ABC


class BaseResource(ABC):

    def __init__(self):
        pass
